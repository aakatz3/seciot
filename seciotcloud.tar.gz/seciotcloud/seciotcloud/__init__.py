from iotsec_settings import *
from flask import json
from flask import Flask,request
import sqlite3

SQL_DB_PATH = '/var/www/seciotcloud/seciotcloud/iotsec.db'


#import pycrypto
                                                                                                                                            
app = Flask(__name__)                                                                                                                        


#
#
#  /service/{GUID}
#                                                                                                                                             
@app.route("/home/<path>", methods=['GET', 'POST'])                                                                                                                
def home_service(path):                                                                                          
	conn = sqlite3.connect(SQL_DB_PATH)   
	c = conn.cursor()

	c.execute("select * from iotdata where home_guid=? and client_or_server=?" , (json.guid, request.json['home_or_mobile']))	

	return c.fetchone()[3]



@app.route("/mobile/<path>", methods=['GET', 'POST'])                                                                                                                
def mobile_service(path):                                                                                          
	conn = sqlite3.connect(SQL_DB_PATH)   
	c = conn.cursor()

	c.execute("insert or replace into iotdata (home_guid, client_or_server,msg_time, state) values (?,?,datetime('now','localtime'),?);" , [request.json['guid'], request.json['home_or_mobile'], request.get_data()])	
	conn.commit()

	c.execute("select * from iotdata where home_guid=? and client_or_server=?" , [request.json['guid'], request.json['home_or_mobile']])	
	return c.fetchone()[3]
	


@app.route("/")                                                                                                                              
def main():                                                                                                                                  
    return "Hello, world!!!"                                                                                                                 

if __name__ == "__main__":                                                                                                                   
    app.run()                                                                                                                                
                                                                                                                                             


