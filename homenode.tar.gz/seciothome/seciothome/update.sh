#!/bin/bash
apt-get update
apt-get dist-upgrade
