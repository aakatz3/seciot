CREATE TABLE nodedata(
	node		integer primary key,
	friendly	text,
	state		integer,
	nodetype	text
);
